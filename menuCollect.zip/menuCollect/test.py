import os
test =os.path.join("..", "Aim_menu", "food_grab",)
print(test)